export type Technology = {
  id: number;
  name: string;
  quadrant: Quadrant;
  ring: Ring;
  description: string;
  active: boolean;
};

export enum Quadrant {
  Tools = 0,
  Techniques = 1,
  Platforms = 2,
  Frameworks = 3,
}

export enum Ring {
  Adopt = 0,
  Trial = 1,
  Assess = 2,
  Hold = 3,
}

export const QuadrantNames: Record<Quadrant, string> = {
  [Quadrant.Tools]: "Tools",
  [Quadrant.Techniques]: "Techniques",
  [Quadrant.Platforms]: "Platforms",
  [Quadrant.Frameworks]: "Frameworks",
};

export const RingNames: Record<Ring, string> = {
  [Ring.Adopt]: "Adopt",
  [Ring.Trial]: "Trial",
  [Ring.Assess]: "Assess",
  [Ring.Hold]: "Hold",
};

export const RingColors: Record<Ring, string> = {
  [Ring.Adopt]: "bg-chart-1", // green
  [Ring.Trial]: "bg-chart-2", // blue
  [Ring.Assess]: "bg-chart-3", // orange
  [Ring.Hold]: "bg-chart-4", // red
};

export const RingTextColors: Record<Ring, string> = {
  [Ring.Adopt]: "text-chart-1", 
  [Ring.Trial]: "text-chart-2",
  [Ring.Assess]: "text-chart-3",
  [Ring.Hold]: "text-chart-4",
};
