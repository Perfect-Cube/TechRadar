import { Technology, Quadrant, Ring } from '@/types';

export const technologies: Technology[] = [
  {
    id: 1,
    name: 'Claude Sonnet',
    quadrant: Quadrant.Techniques,
    ring: Ring.Trial,
    description: 'AI assistant model from Anthropic',
    active: true,
  },
  {
    id: 2,
    name: 'Tuple',
    quadrant: Quadrant.Techniques,
    ring: Ring.Trial,
    description: 'Remote pair programming tool',
    active: true,
  },
  {
    id: 3,
    name: 'YOLO',
    quadrant: Quadrant.Techniques,
    ring: Ring.Trial,
    description: 'Real-time object detection system',
    active: true,
  },
  {
    id: 4,
    name: 'D2',
    quadrant: Quadrant.Techniques,
    ring: Ring.Adopt,
    description: 'Declarative diagramming language',
    active: true,
  },
  {
    id: 5,
    name: 'metabase',
    quadrant: Quadrant.Techniques,
    ring: Ring.Adopt,
    description: 'Business intelligence and analytics tool',
    active: true,
  },
  {
    id: 6,
    name: 'Anything LLM',
    quadrant: Quadrant.Techniques,
    ring: Ring.Adopt,
    description: 'Open-source ChatGPT alternative',
    active: true,
  },
  {
    id: 7,
    name: 'GraphRAG',
    quadrant: Quadrant.Tools,
    ring: Ring.Trial,
    description: 'Graph-based Retrieval Augmented Generation',
    active: true,
  },
  {
    id: 8,
    name: 'Railway',
    quadrant: Quadrant.Platforms,
    ring: Ring.Trial,
    description: 'Application deployment platform',
    active: true,
  },
  {
    id: 9,
    name: 'React',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Adopt,
    description: 'JavaScript library for building user interfaces',
    active: true,
  },
  {
    id: 10,
    name: 'Next.js',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Adopt,
    description: 'React framework for production',
    active: true,
  },
  {
    id: 11,
    name: 'TensorFlow',
    quadrant: Quadrant.Tools,
    ring: Ring.Assess,
    description: 'Open-source machine learning framework',
    active: true,
  },
  {
    id: 12,
    name: 'Kotlin',
    quadrant: Quadrant.Techniques,
    ring: Ring.Assess,
    description: 'Statically typed programming language',
    active: true,
  },
  {
    id: 13,
    name: 'Angular',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Hold,
    description: 'Platform for building mobile and desktop web applications',
    active: true,
  },
  {
    id: 14,
    name: 'AWS Lambda',
    quadrant: Quadrant.Platforms,
    ring: Ring.Adopt,
    description: 'Serverless compute service',
    active: true,
  },
  {
    id: 15,
    name: 'Cypress',
    quadrant: Quadrant.Tools,
    ring: Ring.Adopt,
    description: 'JavaScript end-to-end testing framework',
    active: true,
  },
  {
    id: 16,
    name: 'Docker',
    quadrant: Quadrant.Tools,
    ring: Ring.Adopt,
    description: 'Platform for developing, shipping, and running applications',
    active: true,
  },
  {
    id: 17,
    name: 'Kubernetes',
    quadrant: Quadrant.Platforms,
    ring: Ring.Trial,
    description: 'Container orchestration system',
    active: true,
  },
  {
    id: 18,
    name: 'Svelte',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Assess,
    description: 'Compiler-based JavaScript framework',
    active: true,
  },
  {
    id: 19,
    name: 'WebAssembly',
    quadrant: Quadrant.Techniques,
    ring: Ring.Trial,
    description: 'Binary instruction format for stack-based virtual machines',
    active: true,
  },
  {
    id: 20,
    name: 'Gatsby',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Hold,
    description: 'Static site generator built on React',
    active: true,
  },
  {
    id: 21,
    name: 'Heroku',
    quadrant: Quadrant.Platforms,
    ring: Ring.Hold,
    description: 'Cloud platform as a service',
    active: true,
  },
  {
    id: 22,
    name: 'Jest',
    quadrant: Quadrant.Tools,
    ring: Ring.Adopt,
    description: 'JavaScript testing framework',
    active: true,
  },
  {
    id: 23,
    name: 'TypeScript',
    quadrant: Quadrant.Techniques,
    ring: Ring.Adopt,
    description: 'Strongly typed programming language that builds on JavaScript',
    active: true,
  },
  {
    id: 24,
    name: 'GraphQL',
    quadrant: Quadrant.Techniques,
    ring: Ring.Trial,
    description: 'Query language for your API',
    active: true,
  },
  {
    id: 25,
    name: 'Elastic Search',
    quadrant: Quadrant.Tools,
    ring: Ring.Trial,
    description: 'Distributed, RESTful search and analytics engine',
    active: true,
  },
  {
    id: 26,
    name: 'MongoDB',
    quadrant: Quadrant.Tools,
    ring: Ring.Trial,
    description: 'Document-oriented NoSQL database',
    active: true,
  },
  {
    id: 27,
    name: 'Flutter',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Assess,
    description: 'UI toolkit for building natively compiled applications',
    active: true,
  },
  {
    id: 28,
    name: 'Rust',
    quadrant: Quadrant.Techniques,
    ring: Ring.Assess,
    description: 'Multi-paradigm programming language focused on safety',
    active: true,
  },
  {
    id: 29,
    name: 'Terraform',
    quadrant: Quadrant.Tools,
    ring: Ring.Adopt,
    description: 'Infrastructure as code software tool',
    active: true,
  },
  {
    id: 30,
    name: 'Tailwind CSS',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Adopt,
    description: 'Utility-first CSS framework',
    active: true,
  },
  {
    id: 31,
    name: 'Azure Functions',
    quadrant: Quadrant.Platforms,
    ring: Ring.Trial,
    description: 'Serverless compute service of Azure',
    active: true,
  },
  {
    id: 32,
    name: 'PHP',
    quadrant: Quadrant.Techniques,
    ring: Ring.Hold,
    description: 'Server-side scripting language',
    active: true,
  },
  {
    id: 33,
    name: 'jQuery',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Hold,
    description: 'JavaScript library designed to simplify HTML DOM tree traversal',
    active: true,
  },
  {
    id: 34,
    name: 'Vue.js',
    quadrant: Quadrant.Frameworks,
    ring: Ring.Trial,
    description: 'Progressive JavaScript framework',
    active: true,
  },
  {
    id: 35,
    name: 'Serverless Framework',
    quadrant: Quadrant.Tools,
    ring: Ring.Trial,
    description: 'Framework for building applications on AWS Lambda',
    active: true,
  }
];

export const getQuadrantTechnologies = (quadrant: Quadrant | null) => {
  if (quadrant === null) {
    return technologies;
  }
  return technologies.filter(tech => tech.quadrant === quadrant);
};

export const getRingTechnologies = (ring: Ring | null) => {
  if (ring === null) {
    return technologies;
  }
  return technologies.filter(tech => tech.ring === ring);
};

export const getTechnologyById = (id: number) => {
  return technologies.find(tech => tech.id === id);
};

export const getFilteredTechnologies = (
  quadrant: Quadrant | null, 
  ring: Ring | null,
  searchTerm: string
) => {
  let filtered = technologies;
  
  if (quadrant !== null) {
    filtered = filtered.filter(tech => tech.quadrant === quadrant);
  }
  
  if (ring !== null) {
    filtered = filtered.filter(tech => tech.ring === ring);
  }
  
  if (searchTerm) {
    const searchLower = searchTerm.toLowerCase();
    filtered = filtered.filter(
      tech => 
        tech.name.toLowerCase().includes(searchLower) ||
        tech.description.toLowerCase().includes(searchLower)
    );
  }
  
  return filtered;
};
