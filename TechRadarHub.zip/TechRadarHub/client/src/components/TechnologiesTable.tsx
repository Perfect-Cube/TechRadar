import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Search } from 'lucide-react';
import { Technology, Quadrant, QuadrantNames, Ring, RingNames } from '@/types';
import Pagination from './Pagination';

interface TechnologiesTableProps {
  technologies: Technology[];
  onSelectTechnology: (tech: Technology) => void;
}

const TechnologiesTable: React.FC<TechnologiesTableProps> = ({ 
  technologies, 
  onSelectTechnology 
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [filter, setFilter] = useState('');
  const [quadrantFilter, setQuadrantFilter] = useState<string>('all');
  const [ringFilter, setRingFilter] = useState<string>('all');
  
  // Filtering
  const filteredTechnologies = technologies.filter(tech => {
    const matchesSearch = tech.name.toLowerCase().includes(filter.toLowerCase()) || 
                          tech.description.toLowerCase().includes(filter.toLowerCase());
    
    const matchesQuadrant = quadrantFilter === 'all' || 
                           tech.quadrant.toString() === quadrantFilter;
    
    const matchesRing = ringFilter === 'all' || 
                       tech.ring.toString() === ringFilter;
    
    return matchesSearch && matchesQuadrant && matchesRing;
  });
  
  // Pagination
  const itemsPerPage = 7;
  const totalPages = Math.ceil(filteredTechnologies.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentTechnologies = filteredTechnologies.slice(startIndex, endIndex);

  return (
    <div className="bg-card rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">All Technologies</h2>
        <div className="flex gap-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Filter technologies..."
              className="w-48 bg-accent text-sm pr-8"
              value={filter}
              onChange={(e) => {
                setFilter(e.target.value);
                setCurrentPage(1); // Reset to first page on filter change
              }}
            />
            <Search className="h-4 w-4 absolute right-3 top-2.5 text-muted-foreground" />
          </div>
          
          <Select
            value={quadrantFilter}
            onValueChange={(value) => {
              setQuadrantFilter(value);
              setCurrentPage(1);
            }}
          >
            <SelectTrigger className="h-9 w-40 bg-accent text-sm">
              <SelectValue placeholder="All Quadrants" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Quadrants</SelectItem>
              {Object.values(Quadrant)
                .filter(q => typeof q === 'number')
                .map(q => (
                  <SelectItem key={q} value={q.toString()}>
                    {QuadrantNames[q as Quadrant]}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
          
          <Select
            value={ringFilter}
            onValueChange={(value) => {
              setRingFilter(value);
              setCurrentPage(1);
            }}
          >
            <SelectTrigger className="h-9 w-32 bg-accent text-sm">
              <SelectValue placeholder="All Rings" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Rings</SelectItem>
              {Object.values(Ring)
                .filter(r => typeof r === 'number')
                .map(r => (
                  <SelectItem key={r} value={r.toString()}>
                    {RingNames[r as Ring]}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-muted-foreground">Name</TableHead>
              <TableHead className="text-muted-foreground">Quadrant</TableHead>
              <TableHead className="text-muted-foreground">Ring</TableHead>
              <TableHead className="text-muted-foreground">Description</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="divide-y divide-border">
            {currentTechnologies.map((tech) => (
              <TableRow key={tech.id} className="hover:bg-accent cursor-pointer" onClick={() => onSelectTechnology(tech)}>
                <TableCell className="font-medium whitespace-nowrap">
                  <a href="#" className="text-primary hover:underline" onClick={(e) => {
                    e.preventDefault();
                    onSelectTechnology(tech);
                  }}>
                    {tech.name}
                  </a>
                </TableCell>
                <TableCell className="whitespace-nowrap">
                  <span className="px-2 py-1 text-xs rounded-md bg-accent">
                    {QuadrantNames[tech.quadrant]}
                  </span>
                </TableCell>
                <TableCell className="whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs rounded-md text-white ${
                    tech.ring === Ring.Adopt ? 'bg-chart-1' :
                    tech.ring === Ring.Trial ? 'bg-chart-2' :
                    tech.ring === Ring.Assess ? 'bg-chart-3' :
                    'bg-chart-4'
                  }`}>
                    {RingNames[tech.ring]}
                  </span>
                </TableCell>
                <TableCell>{tech.description}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Pagination 
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
        totalItems={filteredTechnologies.length}
        itemsPerPage={itemsPerPage}
      />
    </div>
  );
};

export default TechnologiesTable;
