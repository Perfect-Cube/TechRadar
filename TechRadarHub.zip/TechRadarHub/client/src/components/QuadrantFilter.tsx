import React from 'react';
import { Button } from '@/components/ui/button';
import { Quadrant, QuadrantNames } from '@/types';

interface QuadrantFilterProps {
  selectedQuadrant: Quadrant | null;
  onSelectQuadrant: (quadrant: Quadrant | null) => void;
}

const QuadrantFilter: React.FC<QuadrantFilterProps> = ({
  selectedQuadrant,
  onSelectQuadrant,
}) => {
  return (
    <div className="flex gap-2 flex-wrap">
      <Button
        variant={selectedQuadrant === null ? "default" : "secondary"}
        className={selectedQuadrant === null ? "bg-accent" : "bg-background-surface"}
        size="sm"
        onClick={() => onSelectQuadrant(null)}
      >
        All Quadrants
      </Button>
      {Object.values(Quadrant)
        .filter((q) => typeof q === 'number')
        .map((quadrant) => (
          <Button
            key={quadrant}
            variant={selectedQuadrant === quadrant ? "default" : "secondary"}
            className={selectedQuadrant === quadrant ? "bg-primary" : "bg-accent"}
            size="sm"
            onClick={() => onSelectQuadrant(quadrant as Quadrant)}
          >
            {QuadrantNames[quadrant as Quadrant]}
          </Button>
        ))}
    </div>
  );
};

export default QuadrantFilter;
