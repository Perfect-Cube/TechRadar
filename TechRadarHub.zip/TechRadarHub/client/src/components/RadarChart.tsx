import React, { useEffect, useRef, useState } from 'react';
import { Technology, Quadrant, Ring, QuadrantNames, RingColors } from '@/types';

interface RadarChartProps {
  technologies: Technology[];
  selectedTechnology: Technology | null;
  onSelectTechnology: (technology: Technology) => void;
}

const RadarChart: React.FC<RadarChartProps> = ({
  technologies,
  selectedTechnology,
  onSelectTechnology,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ width: 600, height: 600 });

  useEffect(() => {
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        const minDimension = Math.min(width, height);
        setSize({ width: minDimension, height: minDimension });
      }
    });

    const container = canvasRef.current?.parentElement;
    if (container) {
      resizeObserver.observe(container);
    }

    return () => {
      if (container) {
        resizeObserver.unobserve(container);
      }
    };
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = size.width;
    canvas.height = size.height;

    // Canvas setup
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 50;

    // Colors
    const ringColors = [
      'rgba(40, 40, 40, 0.8)',
      'rgba(68, 68, 68, 0.8)',
      'rgba(96, 96, 96, 0.8)',
      'rgba(128, 32, 32, 0.6)',
    ];
    const quadrantLineColor = 'rgba(100, 100, 100, 0.5)';
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw rings
    for (let i = 0; i < 4; i++) {
      const currentRadius = radius * (0.25 + i * 0.25);
      ctx.beginPath();
      ctx.arc(centerX, centerY, currentRadius, 0, 2 * Math.PI);
      ctx.fillStyle = ringColors[i];
      ctx.fill();
      ctx.strokeStyle = 'rgba(100, 100, 100, 0.3)';
      ctx.stroke();
    }

    // Draw quadrant lines
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - radius);
    ctx.lineTo(centerX, centerY + radius);
    ctx.strokeStyle = quadrantLineColor;
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(centerX - radius, centerY);
    ctx.lineTo(centerX + radius, centerY);
    ctx.strokeStyle = quadrantLineColor;
    ctx.stroke();

    // Draw quadrant labels
    ctx.font = '16px Inter, sans-serif';
    ctx.fillStyle = '#e0e0e0';
    ctx.textAlign = 'center';
    
    // Frameworks (top-left)
    ctx.fillText(QuadrantNames[Quadrant.Frameworks], centerX - radius * 0.7, centerY - radius * 0.7);
    
    // Techniques (top-right)
    ctx.fillText(QuadrantNames[Quadrant.Techniques], centerX + radius * 0.7, centerY - radius * 0.7);
    
    // Tools (bottom-left)
    ctx.fillText(QuadrantNames[Quadrant.Tools], centerX - radius * 0.7, centerY + radius * 0.7);
    
    // Platforms (bottom-right)
    ctx.fillText(QuadrantNames[Quadrant.Platforms], centerX + radius * 0.7, centerY + radius * 0.7);

    // Draw dots for technologies
    const techPositions: { x: number; y: number; tech: Technology }[] = [];

    technologies.forEach((tech) => {
      // Calculate angle for quadrant
      let baseAngle = 0;
      switch (tech.quadrant) {
        case Quadrant.Frameworks: // top-left
          baseAngle = Math.PI * 1.25;
          break;
        case Quadrant.Techniques: // top-right
          baseAngle = Math.PI * 1.75;
          break;
        case Quadrant.Tools: // bottom-left
          baseAngle = Math.PI * 0.75;
          break;
        case Quadrant.Platforms: // bottom-right
          baseAngle = Math.PI * 0.25;
          break;
      }

      // Random angle offset within quadrant
      const angleOffset = (Math.random() - 0.5) * Math.PI * 0.4;
      const angle = baseAngle + angleOffset;

      // Calculate position based on ring
      const ringRadius = radius * (0.2 + (tech.ring + 1) * 0.18);
      const x = centerX + Math.cos(angle) * ringRadius;
      const y = centerY + Math.sin(angle) * ringRadius;

      // Store position for click detection
      techPositions.push({ x, y, tech });

      // Draw the dot (bigger and different color if selected)
      const isSelected = selectedTechnology?.id === tech.id;
      const dotRadius = isSelected ? 10 : 8;

      // Determine color based on ring
      let dotColor;
      switch (tech.ring) {
        case Ring.Adopt:
          dotColor = '#4caf50';
          break;
        case Ring.Trial:
          dotColor = '#2196f3';
          break;
        case Ring.Assess:
          dotColor = '#ff9800';
          break;
        case Ring.Hold:
          dotColor = '#f44336';
          break;
      }

      ctx.beginPath();
      ctx.arc(x, y, dotRadius, 0, 2 * Math.PI);
      ctx.fillStyle = dotColor;
      ctx.fill();
      ctx.strokeStyle = isSelected ? '#ffffff' : 'rgba(255,255,255,0.6)';
      ctx.lineWidth = isSelected ? 2 : 1;
      ctx.stroke();
    });

    // Handle click events
    canvas.onclick = (event) => {
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      // Find if click is near any technology dot
      for (const { x: dotX, y: dotY, tech } of techPositions) {
        const distance = Math.sqrt(Math.pow(x - dotX, 2) + Math.pow(y - dotY, 2));
        if (distance <= 10) {
          onSelectTechnology(tech);
          break;
        }
      }
    };

    // Add hover effect
    canvas.onmousemove = (event) => {
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      let isOverDot = false;
      for (const { x: dotX, y: dotY } of techPositions) {
        const distance = Math.sqrt(Math.pow(x - dotX, 2) + Math.pow(y - dotY, 2));
        if (distance <= 10) {
          isOverDot = true;
          canvas.style.cursor = 'pointer';
          break;
        }
      }

      if (!isOverDot) {
        canvas.style.cursor = 'default';
      }
    };

  }, [technologies, selectedTechnology, size, onSelectTechnology]);

  return (
    <div className="bg-card rounded-lg p-4 relative w-full h-full">
      <canvas
        ref={canvasRef}
        width={size.width}
        height={size.height}
        className="mx-auto"
      />
    </div>
  );
};

export default RadarChart;
