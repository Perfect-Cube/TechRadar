import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ChevronRight, ChevronDown } from 'lucide-react';
import { Technology, RingNames, QuadrantNames } from '@/types';
import { Badge } from '@/components/ui/badge';

interface SelectedTechnologyCardProps {
  technology: Technology | null;
}

const SelectedTechnologyCard: React.FC<SelectedTechnologyCardProps> = ({ technology }) => {
  if (!technology) {
    return (
      <Card className="shadow-lg h-full">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg border-b border-border pb-3">Selected Technology</CardTitle>
        </CardHeader>
        <CardContent className="mt-4">
          <p className="text-muted-foreground text-sm">
            Click on a technology in the radar to view details.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg border-b border-border pb-3">Selected Technology</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <h4 className="text-xl font-medium text-foreground">{technology.name}</h4>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline" className="bg-muted text-foreground text-xs px-2 py-1 rounded">
              {RingNames[technology.ring]}
            </Badge>
            <Badge className="bg-primary text-foreground text-xs px-2 py-1 rounded">
              {QuadrantNames[technology.quadrant]}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-4">{technology.description}</p>
        </div>
        <a href="#" className="flex items-center text-primary text-sm hover:underline">
          View full details
          <ChevronRight className="h-4 w-4 ml-1" />
        </a>
      </CardContent>
      <CardFooter className="flex justify-between border-t border-border pt-4">
        <span className="text-sm text-muted-foreground">Related Projects</span>
        <ChevronDown className="h-5 w-5 text-muted-foreground" />
      </CardFooter>
    </Card>
  );
};

export default SelectedTechnologyCard;
