import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Ring, RingNames, RingColors } from '@/types';

const LegendCard: React.FC = () => {
  return (
    <Card className="shadow-lg h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg border-b border-border pb-3">Legend</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Object.values(Ring)
            .filter((r) => typeof r === 'number')
            .map((ring) => (
              <div key={ring} className="flex items-center">
                <span className={`inline-block w-4 h-4 rounded-full ${RingColors[ring as Ring]} mr-3`}></span>
                <span>{RingNames[ring as Ring]}</span>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default LegendCard;
