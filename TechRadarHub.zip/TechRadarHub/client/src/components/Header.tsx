import React from 'react';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

interface HeaderProps {
  onSearch: (term: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch }) => {
  return (
    <header className="bg-background border-b border-border">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          {/* VW Logo */}
          <svg
            className="h-8 w-8 mr-3"
            viewBox="0 0 48 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle cx="24" cy="24" r="24" fill="#14213d" />
            <path
              d="M24 4C12.954 4 4 12.954 4 24s8.954 20 20 20 20-8.954 20-20S35.046 4 24 4zm0 5.727c7.882 0 14.273 6.39 14.273 14.273 0 7.882-6.39 14.273-14.273 14.273-7.882 0-14.273-6.39-14.273-14.273C9.727 16.117 16.117 9.727 24 9.727z"
              fill="#fff"
            />
            <path
              d="M18.965 29.035h10.07L24 24l-5.035 5.035zm2.94-14.07h4.19L24 12.87l-2.095 2.095z"
              fill="#fff"
            />
          </svg>
          <h1 className="font-semibold text-xl bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">VW Tech Radar</h1>
        </div>
        <div className="flex items-center space-x-6">
          <a href="#" className="text-blue-400 hover:text-blue-500 font-medium">
            Radar
          </a>
          <a href="#" className="text-muted-foreground hover:text-foreground font-medium">
            Technologies
          </a>
          <div className="relative w-64">
            <Search className="h-4 w-4 absolute left-3 top-2.5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search technologies..."
              className="w-full pl-9 pr-3 bg-secondary/80 text-sm border-0 focus-visible:ring-1 focus-visible:ring-blue-400"
              onChange={(e) => onSearch(e.target.value)}
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
