import React, { useState } from 'react';
import Header from '@/components/Header';
import RadarChart from '@/components/RadarChart';
import LegendCard from '@/components/LegendCard';
import SelectedTechnologyCard from '@/components/SelectedTechnologyCard';
import TechnologiesTable from '@/components/TechnologiesTable';
import QuadrantFilter from '@/components/QuadrantFilter';
import { technologies } from '@/lib/techRadarData';
import { Technology, Quadrant } from '@/types';

const Home: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedQuadrant, setSelectedQuadrant] = useState<Quadrant | null>(null);
  const [selectedTechnology, setSelectedTechnology] = useState<Technology | null>(null);

  // Filter technologies based on search and selected quadrant
  const filteredTechnologies = technologies.filter(tech => {
    const matchesSearch = !searchTerm || 
                          tech.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          tech.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesQuadrant = selectedQuadrant === null || tech.quadrant === selectedQuadrant;
    
    return matchesSearch && matchesQuadrant;
  });

  const handleSearch = (term: string) => {
    setSearchTerm(term);
  };

  const handleSelectQuadrant = (quadrant: Quadrant | null) => {
    setSelectedQuadrant(quadrant);
  };

  const handleSelectTechnology = (technology: Technology) => {
    setSelectedTechnology(technology);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header onSearch={handleSearch} />
      
      <section className="container mx-auto px-4 py-6 flex-grow">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-foreground">Technology Radar Visualization</h2>
          
          <div className="relative">
            <input
              type="text"
              placeholder="Search technologies..."
              className="bg-accent py-1 px-4 rounded-md text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary w-64"
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
            />
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 absolute right-3 top-2 text-muted-foreground"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          <QuadrantFilter
            selectedQuadrant={selectedQuadrant}
            onSelectQuadrant={handleSelectQuadrant}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          {/* Radar Visualization */}
          <div className="md:col-span-2 h-[600px]">
            <RadarChart
              technologies={filteredTechnologies}
              selectedTechnology={selectedTechnology}
              onSelectTechnology={handleSelectTechnology}
            />
          </div>

          {/* Selected Technology Details */}
          <div className="flex flex-col gap-6">
            <div className="h-1/2">
              <SelectedTechnologyCard technology={selectedTechnology} />
            </div>
            <div className="h-1/2">
              <LegendCard />
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-6 mt-6">
        <TechnologiesTable 
          technologies={technologies} 
          onSelectTechnology={handleSelectTechnology} 
        />
      </section>
    </div>
  );
};

export default Home;
