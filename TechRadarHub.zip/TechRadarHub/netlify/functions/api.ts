import { Handler } from '@netlify/functions';
import { technologies } from '../../client/src/lib/techRadarData';

export const handler: Handler = async (event, context) => {
  // For example, return all technologies
  if (event.path === '/.netlify/functions/api/technologies') {
    return {
      statusCode: 200,
      body: JSON.stringify({ technologies }),
      headers: {
        'Content-Type': 'application/json',
      },
    };
  }

  // Default response
  return {
    statusCode: 404,
    body: JSON.stringify({ message: 'Not found' }),
  };
};